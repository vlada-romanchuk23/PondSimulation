﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PondSimulation
{
    public class FishType
    {
        public string Type { get; }
        public Color Color { get; }
        public int Size { get; }

        public FishType(string type, Color color, int size)
        {
            Type = type;
            Color = color;
            Size = size;
        }

        public void Draw(Graphics graphics, int x, int y)
        {
            // Тіло рибки (еліпс)
            using (Brush bodyBrush = new SolidBrush(Color))
            {
                graphics.FillEllipse(bodyBrush, x, y, Size, Size / 2);
            }

            // Хвіст рибки (трикутник)
            Point[] tailPoints =
            {
        new Point(x, y + Size / 4),
        new Point(x - Size / 4, y),
        new Point(x - Size / 4, y + Size / 2)
    };

            using (Brush tailBrush = new SolidBrush(Color))
            {
                graphics.FillPolygon(tailBrush, tailPoints);
            }

            // Око рибки (маленьке біле коло)
            using (Brush eyeBrush = new SolidBrush(Color.White))
            {
                graphics.FillEllipse(eyeBrush, x + Size / 2, y + Size / 8, Size / 8, Size / 8);
            }
        }
    }
}
