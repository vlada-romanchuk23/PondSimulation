﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PondSimulation
{
    public class FishFactory
    {
        private readonly Dictionary<string, FishType> _fishTypes = new Dictionary<string, FishType>();

        public FishType GetFishType(string type, Color color, int size)
        {
            string key = $"{type}_{color}_{size}";
            if (!_fishTypes.ContainsKey(key))
            {
                _fishTypes[key] = new FishType(type, color, size);
            }
            return _fishTypes[key];
        }
    }
}
