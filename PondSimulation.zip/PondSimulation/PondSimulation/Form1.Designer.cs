﻿namespace PondSimulation
{
    partial class PondForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddFishButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AddFishButton
            // 
            this.AddFishButton.Location = new System.Drawing.Point(47, 38);
            this.AddFishButton.Name = "AddFishButton";
            this.AddFishButton.Size = new System.Drawing.Size(75, 23);
            this.AddFishButton.TabIndex = 0;
            this.AddFishButton.Text = "Add Fish";
            this.AddFishButton.UseVisualStyleBackColor = true;
            this.AddFishButton.Click += new System.EventHandler(this.AddFishButton_Click);
            // 
            // PondForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.AddFishButton);
            this.Name = "PondForm";
            this.Text = "PondForm";
            this.Load += new System.EventHandler(this.PondForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AddFishButton;
    }
}

