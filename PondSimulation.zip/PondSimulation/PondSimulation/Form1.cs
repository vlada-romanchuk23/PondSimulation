﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PondSimulation
{
    public partial class PondForm : Form
    {
        public PondForm()
        {
            InitializeComponent();
            this.Paint += PondForm_Paint;
        }

        private void PondForm_Load(object sender, EventArgs e)
        {

        }
        private Pond pond = new Pond();
        private FishFactory fishFactory = new FishFactory();

        

        private void PondForm_Paint(object sender, PaintEventArgs e)
        {
            pond.Draw(e.Graphics);
        }

        private void AddFishButton_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int x = random.Next(this.ClientSize.Width);
            int y = random.Next(this.ClientSize.Height);

            FishType fishType = fishFactory.GetFishType("Goldfish", Color.Gold, 30);
            pond.AddFish(x, y, fishType);

            Invalidate(); // Оновлює форму для відображення нових рибок
        }

    }
}
