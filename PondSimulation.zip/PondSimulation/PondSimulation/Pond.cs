﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PondSimulation
{
    public class Pond
    {
        private readonly List<Fish> _fishes = new List<Fish>();

        public void AddFish(int x, int y, FishType fishType)
        {
            Fish fish = new Fish(x, y, fishType);
            _fishes.Add(fish);
        }

        public void Draw(Graphics graphics)
        {
            foreach (var fish in _fishes)
            {
                fish.Draw(graphics);
            }
        }
    }
}
