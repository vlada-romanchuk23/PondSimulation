﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace PondSimulation
{
    public class Fish
    {
        public int X { get; }
        public int Y { get; }
        public FishType FishType { get; }

        public Fish(int x, int y, FishType fishType)
        {
            X = x;
            Y = y;
            FishType = fishType;
        }

        public void Draw(Graphics graphics)
        {
            FishType.Draw(graphics, X, Y);
        }
    }

}
